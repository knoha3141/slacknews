"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GeminiClient = void 0;
const generative_ai_1 = require("@google/generative-ai");
class GeminiClient {
    constructor(apiKey) {
        this.genAI = new generative_ai_1.GoogleGenerativeAI(apiKey);
        this.model = this.genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
    }
    async generateNewsReport() {
        const prompt = `
あなたは起業家向けのニュースキュレーターです。昨日から今日にかけての最新ニュースを調査し、起業に役立つテック、経済、ビジネス関連の重要なニュースを5-7件選んでレポートを作成してください。

各ニュースには以下の情報を含めてください：
- タイトル: ニュースの見出し
- カテゴリー: tech、business、economyのいずれか
- 詳細情報: 500文字以上の詳しい要約と起業家への影響分析
- 重要度: 1-5の数値（5が最重要）
- ソースURL: 信頼できるニュースソースのURL

対象となるニュースソース：
- TechCrunch, Bloomberg, Reuters, Nikkei, VentureBeat, Harvard Business Review, MIT Technology Review, Forbes

以下のJSON形式で回答してください：
{
  "articles": [
    {
      "title": "ニュースタイトル",
      "category": "tech",
      "summary": "500文字以上の詳細な要約と分析...",
      "importance": 4,
      "sourceUrl": "https://example.com/article"
    }
  ]
}
`;
        try {
            const result = await this.model.generateContent(prompt);
            const response = await result.response;
            const text = response.text();
            // JSONを抽出（```json マークダウンを除去）
            console.log('Raw Gemini response:', text);
            // ```json から ``` までの部分を抽出、またはJSONオブジェクトを直接抽出
            let jsonString = text;
            // ```json が含まれている場合は除去
            if (text.includes('```json')) {
                const jsonStart = text.indexOf('{');
                const jsonEnd = text.lastIndexOf('}');
                if (jsonStart === -1 || jsonEnd === -1) {
                    throw new Error(`No valid JSON object found in response. Response: ${text.substring(0, 500)}`);
                }
                jsonString = text.substring(jsonStart, jsonEnd + 1);
            }
            else {
                // 通常のJSON抽出
                const jsonMatch = text.match(/\{[\s\S]*\}/);
                if (!jsonMatch) {
                    throw new Error(`No valid JSON found in response. Response: ${text.substring(0, 500)}`);
                }
                jsonString = jsonMatch[0];
            }
            console.log('Extracted JSON:', jsonString);
            const parsedData = JSON.parse(jsonString);
            return {
                date: new Date().toISOString().split('T')[0],
                articles: parsedData.articles,
                totalCount: parsedData.articles.length,
                generatedAt: new Date().toISOString()
            };
        }
        catch (error) {
            console.error('Gemini API Error:', error);
            throw new Error(`Failed to generate news report: ${error}`);
        }
    }
    async validateApiKey() {
        try {
            const result = await this.model.generateContent('Hello');
            return true;
        }
        catch (error) {
            console.error('API Key validation failed:', error);
            return false;
        }
    }
}
exports.GeminiClient = GeminiClient;
